package day9.함수;

public class 실습문제9_클래스문제3_Score {
	   /*
	   - name 학생이름
	   - kor  국어성적
	   - eng 영어성적
	   - avg 평균 
	   */  
	
	String name;
	int kor;
	int eng;
	int avg;
}
