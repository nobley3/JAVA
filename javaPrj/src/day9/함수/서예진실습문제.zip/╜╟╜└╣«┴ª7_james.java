package day9.함수;

public class 실습문제7_james {
	/*
	이 사람이 나이
	이 사람의 이름
	이 사람의 결혼 여부
	이사람의 자녀수
	*/
	
	String name;
	int age;
	int ch;
	boolean isMarried = true;
}
