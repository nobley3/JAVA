package day9.함수;

public class 실습문제8_클래스문제2 {
	/*
	주문번호: 201803120001
	주문자아이디: abc123
	주문날짜:2018년3월12일
	주문자이름: 홍길순
	주문상품번호😛D0345-12
	배송주소: 서울시 영등포구 여의도동 20번지
	*/
	
	long number; //int 4byte long 8byte
	String id;
	String day;
	String name;
	String ordernum;
	String adrs;
}
