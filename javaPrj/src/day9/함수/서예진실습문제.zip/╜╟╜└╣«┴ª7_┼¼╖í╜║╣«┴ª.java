package day9.함수;

public class 실습문제7_클래스문제 {

	public static void main(String[] args) {

		실습문제7_james q = new 실습문제7_james();
		
		q.name="james";
		q.age=40;
		q.ch=3;
		q.isMarried=true;
		
		System.out.println("이름:"+q.name);
		System.out.println("나이:"+q.age+"살");
		System.out.println("자녀수:"+q.ch+"명");
		System.out.println("결혼유무:"+q.isMarried);
		
		
		
		
	}

}
